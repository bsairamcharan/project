# wol-sample-application

Sample project of Week of Learning Webathon

## Description

For the webathon project, if you are not sure about what to create, you can make your project based on this project.

## Download

You can download this project by downloading the files on your local by clicking the green button on this page.
